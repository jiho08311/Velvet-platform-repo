import { supabaseAdmin } from "@/infrastructure/supabase/admin"
import { createMediaSignedUrl } from "@/modules/media/server/create-media-signed-url"
import { buildPostRenderInput } from "@/modules/post/ui/post-render-input"

export type MyPostListItem = {
  id: string
  creatorId: string
  text: string
  status: "draft" | "scheduled" | "published" | "archived"
  visibility: "public" | "subscribers" | "paid"
  isLocked: boolean
  createdAt: string
  publishedAt: string | null
  media?: {
    url: string
    type?: "image" | "video" | "audio" | "file"
  }[]
}

export type GetMyPostsInput = {
  creatorId: string
  limit?: number
  cursor?: string | null
  status?: "draft" | "scheduled" | "published"
}

export type GetMyPostsResult = {
  items: MyPostListItem[]
  nextCursor: string | null
}

type CreatorRow = {
  id: string
  user_id: string
}

type PostRow = {
  id: string
  creator_id: string
  content: string | null
  status: "draft" | "scheduled" | "published" | "archived"
  visibility: "public" | "subscribers" | "paid"
  created_at: string
  published_at: string | null
}

type MediaRow = {
  post_id: string
  storage_path: string
  type: "image" | "video" | "audio" | "file" | null
  mime_type: string | null
  sort_order: number
  status: "processing" | "ready" | "failed"
}

type PostBlockRow = {
  id: string
  post_id: string
  type: "text" | "image" | "video" | "audio" | "file"
  content: string | null
  media_id: string | null
  sort_order: number
  created_at: string
  editor_state: unknown | null
}

function resolveMediaType(row: MediaRow): "image" | "video" | "audio" | "file" {
  if (
    row.type === "image" ||
    row.type === "video" ||
    row.type === "audio" ||
    row.type === "file"
  ) {
    return row.type
  }

  if (typeof row.mime_type === "string") {
    if (row.mime_type.startsWith("image/")) return "image"
    if (row.mime_type.startsWith("video/")) return "video"
    if (row.mime_type.startsWith("audio/")) return "audio"
  }

  return "file"
}

export async function getMyPosts(
  input: GetMyPostsInput
): Promise<GetMyPostsResult> {
  const rawCreatorId = input.creatorId.trim()

  if (!rawCreatorId) {
    throw new Error("Creator id is required")
  }

  const limit = Math.max(1, Math.min(input.limit ?? 20, 100))

  const { data: creator, error: creatorError } = await supabaseAdmin
    .from("creators")
    .select("id, user_id")
    .or(`id.eq.${rawCreatorId},user_id.eq.${rawCreatorId}`)
    .maybeSingle<CreatorRow>()

  if (creatorError) {
    throw creatorError
  }

  if (!creator) {
    return {
      items: [],
      nextCursor: null,
    }
  }

  let postQuery = supabaseAdmin
    .from("posts")
    .select(
      "id, creator_id, content, status, visibility, created_at, published_at"
    )
    .eq("creator_id", creator.id)
    .is("deleted_at", null)

  if (input.status) {
    postQuery = postQuery.eq("status", input.status)
  }

  postQuery = postQuery
    .order("created_at", { ascending: false })
    .limit(limit)

  const { data: posts, error: postsError } = await postQuery

  if (postsError) {
    throw postsError
  }

  const postIds = (posts ?? []).map((post) => post.id)

  if (postIds.length === 0) {
    return {
      items: [],
      nextCursor: null,
    }
  }

  const { data: mediaRows, error: mediaError } = await supabaseAdmin
    .from("media")
    .select("post_id, storage_path, type, mime_type, sort_order, status")
    .in("post_id", postIds)
    .in("status", ["processing", "ready"])
    .order("sort_order", { ascending: true })
    .returns<MediaRow[]>()

  if (mediaError) {
    throw mediaError
  }

  const { data: blockRows, error: blockRowsError } = await supabaseAdmin
    .from("post_blocks")
    .select("id, post_id, type, content, media_id, sort_order, created_at, editor_state")
    .in("post_id", postIds)
    .order("sort_order", { ascending: true })
    .returns<PostBlockRow[]>()

  if (blockRowsError) {
    throw blockRowsError
  }

  const mediaMap = new Map<string, MediaRow[]>()

  for (const media of mediaRows ?? []) {
    const current = mediaMap.get(media.post_id) ?? []
    current.push(media)
    mediaMap.set(media.post_id, current)
  }

  const blocksMap = new Map<string, PostBlockRow[]>()

  for (const block of blockRows ?? []) {
    const current = blocksMap.get(block.post_id) ?? []
    current.push(block)
    blocksMap.set(block.post_id, current)
  }

  const items = await Promise.all(
    (posts ?? []).map(async (post) => {
      const mediaRowsForPost = mediaMap.get(post.id) ?? []

      const media = await Promise.all(
        mediaRowsForPost.map(async (item) => {
          const url = await createMediaSignedUrl({
            storagePath: item.storage_path,
            viewerUserId: creator.user_id,
            creatorUserId: creator.user_id,
            visibility: post.visibility,
            isSubscribed: true,
            hasPurchased: true,
          })

          return {
            id: `${post.id}:${item.sort_order}:${item.storage_path}`,
            url,
            type: resolveMediaType(item),
            mimeType: item.mime_type,
            sortOrder: item.sort_order,
          }
        })
      )

        const renderInput = buildPostRenderInput({
        text: post.content ?? "",
        blocks: (blocksMap.get(post.id) ?? []).map((block) => ({
          id: block.id,
          postId: block.post_id,
          type: block.type,
          content: block.content,
          mediaId: block.media_id,
          sortOrder: block.sort_order,
          createdAt: block.created_at,
          editorState: block.editor_state ?? null,
        })),
        media: media.map((item) => ({
          id: item.id,
          url: item.url,
          type: item.type,
          mimeType: item.mimeType,
          sortOrder: item.sortOrder,
        })),
      })

      return {
        id: post.id,
        creatorId: post.creator_id,
           text: renderInput.blockText ?? "",
        status: post.status,
        visibility: post.visibility,
        isLocked: false,
        createdAt: post.created_at,
        publishedAt: post.published_at,
        media: media.map((item) => ({
          url: item.url,
          type: item.type,
        })),
      }
    })
  )

  return {
    items,
    nextCursor: null,
  }
}