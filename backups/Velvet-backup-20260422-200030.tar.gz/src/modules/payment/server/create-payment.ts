import { supabaseAdmin } from "@/infrastructure/supabase/admin"

type PaymentType = "subscription" | "tip" | "ppv_message" | "ppv_post"
type PaymentStatus = "pending" | "succeeded" | "failed" | "refunded"
type PaymentProvider = "toss" | "mock"
type PaymentTargetType = "post" | "message" | null

type CreatePaymentInput = {
  userId: string
  creatorId?: string
  type: PaymentType
  status?: PaymentStatus
  amount: number
  currency?: string
  provider?: PaymentProvider
  providerReferenceId?: string
  targetType?: PaymentTargetType
  targetId?: string
}

type PaymentRow = {
  id: string
  user_id: string
  creator_id: string | null
  type: PaymentType
  status: PaymentStatus
  amount: number
  currency: string
  provider: PaymentProvider
  provider_reference_id: string | null
  target_type: PaymentTargetType
  target_id: string | null
  created_at: string
  updated_at: string
}

export default async function createPayment({
  userId,
  creatorId,
  type,
  status = "pending",
  amount,
  currency = "KRW",
  provider = "mock",
  providerReferenceId,
  targetType = null,
  targetId,
}: CreatePaymentInput) {
  if (providerReferenceId) {
    const { data: existingPayment, error: existingPaymentError } =
      await supabaseAdmin
        .from("payments")
        .select(
          "id, user_id, creator_id, type, status, amount, currency, provider, provider_reference_id, target_type, target_id, created_at, updated_at"
        )
        .eq("provider_reference_id", providerReferenceId)
        .maybeSingle<PaymentRow>()

    if (existingPaymentError) {
      throw existingPaymentError
    }

    if (existingPayment) {
      return {
        id: existingPayment.id,
        userId: existingPayment.user_id,
        creatorId: existingPayment.creator_id ?? undefined,
        type: existingPayment.type,
        status: existingPayment.status,
        amount: existingPayment.amount,
        currency: existingPayment.currency,
        provider: existingPayment.provider,
        providerReferenceId:
          existingPayment.provider_reference_id ?? undefined,
        targetType: existingPayment.target_type,
        targetId: existingPayment.target_id ?? undefined,
        createdAt: existingPayment.created_at,
        updatedAt: existingPayment.updated_at,
      }
    }
  }

  const { data, error } = await supabaseAdmin
    .from("payments")
    .insert({
      user_id: userId,
      creator_id: creatorId ?? null,
      type,
      status,
      amount: amount,
      currency,
      provider,
      provider_reference_id: providerReferenceId ?? null,
      target_type: targetType,
      target_id: targetId ?? null,
    })
    .select(
      "id, user_id, creator_id, type, status, amount, currency, provider, provider_reference_id, target_type, target_id, created_at, updated_at"
    )
    .single<PaymentRow>()

  if (error) {
    throw error
  }

  return {
    id: data.id,
    userId: data.user_id,
    creatorId: data.creator_id ?? undefined,
    type: data.type,
    status: data.status,
    amount: data.amount,
    currency: data.currency,
    provider: data.provider,
    providerReferenceId: data.provider_reference_id ?? undefined,
    targetType: data.target_type,
    targetId: data.target_id ?? undefined,
    createdAt: data.created_at,
    updatedAt: data.updated_at,
  }
}