import { RestrictedStateShell } from "@/shared/ui/RestrictedStateShell"

type SubscriptionDisplayStatus = "active" | "canceled" | "expired" | "inactive"

type SubscriptionStatusCardProps = {
  status: SubscriptionDisplayStatus
  currentPeriodEndAt?: string | null
}

function formatDate(value?: string | null) {
  if (!value) return null

  const date = new Date(value)

  if (Number.isNaN(date.getTime())) {
    return null
  }

  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date)
}

export function SubscriptionStatusCard({
  status,
  currentPeriodEndAt,
}: SubscriptionStatusCardProps) {
  const formattedEndDate = formatDate(currentPeriodEndAt)

  if (status === "inactive") {
    return (
      <RestrictedStateShell
        tone="neutral"
        badgeLabel="Inactive"
        badgeTone="subtle"
        title="구독이 필요합니다"
        description="구독하면 크리에이터의 전용 콘텐츠를 확인할 수 있습니다."
      />
    )
  }

  if (status === "expired") {
    return (
      <RestrictedStateShell
        tone="danger"
        badgeLabel="Expired"
        badgeTone="danger"
        title="구독이 종료되었습니다"
        description={
          formattedEndDate
            ? `${formattedEndDate}에 이용이 종료되었습니다. 다시 구독하면 전용 콘텐츠를 계속 확인할 수 있습니다.`
            : "이용이 종료되었습니다. 다시 구독하면 전용 콘텐츠를 계속 확인할 수 있습니다."
        }
      />
    )
  }

  if (status === "canceled") {
    return (
      <RestrictedStateShell
        tone="warning"
        badgeLabel="Canceled"
        badgeTone="warning"
        title="구독 종료 예정"
        description={
          formattedEndDate
            ? `${formattedEndDate}까지 전용 콘텐츠를 이용할 수 있습니다.`
            : "현재 결제 주기 종료 시 이용이 종료됩니다."
        }
      />
    )
  }

  return (
    <RestrictedStateShell
      tone="success"
      badgeLabel="Active"
      badgeTone="success"
      title="구독 중"
      description={
        formattedEndDate
          ? `다음 결제 기준일은 ${formattedEndDate}입니다.`
          : "현재 전용 콘텐츠를 이용할 수 있습니다."
      }
    />
  )
}